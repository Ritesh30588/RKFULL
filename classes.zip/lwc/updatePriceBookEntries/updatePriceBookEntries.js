import { LightningElement } from "lwc";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
//import updatePriceBookEntries from '@salesforce/apex/UpdatePriceBookEntriesBatch.updatePriceBookEntries';
import updateAllPriceBooksEntries from "@salesforce/apex/UpdateAllPriceBooksEntriesBatch.updateAllPriceBooksEntries";
import updateAllProductCost from "@salesforce/apex/UpdateAllProductCostBatch.updateAllProductCost";

export default class UpdatePriceBookEntries extends LightningElement {
  /*
	handleUpdatePriceBookClick() {
		this.dispatchEvent(
			new ShowToastEvent({
				title: "Success",
				message: "Price Book Entries updating process Started In Backgroud.",
				variant: "success",
			})
		);
		updatePriceBookEntries().then(result => {

			console.log(result);
		}).catch(error => {

			console.log(error);
		});
	}
	*/

  handleUpdateAllPriceBookEntriesClick() {
    this.dispatchEvent(
      new ShowToastEvent({
        title: "Success",
        message:
          "Price Book Entries and Product code updating process Started In Backgroud.",
        variant: "success"
      })
    );
    updateAllPriceBooksEntries()
      .then((result) => {
        console.log(result);
      })
      .catch((error) => {
        console.log(error);
      });

    updateAllProductCost()
      .then((result) => {
        console.log(result);
      })
      .catch((error) => {
        console.log(error);
      });
  }
}
