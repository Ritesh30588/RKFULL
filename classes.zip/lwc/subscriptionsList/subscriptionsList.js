import { LightningElement, api } from "lwc";
import getSubscriptions from "@salesforce/apex/SubscriptionListContoller.getSubscriptions";

export default class SubscriptionsList extends LightningElement {
  @api showInactiveSubscription;
  @api relatedListLable;
  @api recordId;
  viewAllUrl;
  columns = [
    {
      label: "Subscription #",
      fieldName: "Name",
      type: "text",
      sortable: false
    },
    {
      label: "Product Name",
      fieldName: "SBQQ__ProductName__c",
      type: "text",
      sortable: false,
      initialWidth: 300
    },
    {
      label: "Line Description",
      fieldName: "Line_Description__c",
      type: "text",
      sortable: false
    },
    {
      label: "Quantity",
      fieldName: "SBQQ__Quantity__c",
      type: "double",
      sortable: false
    },
    {
      label: "Subscription Start Date",
      fieldName: "SBQQ__SubscriptionStartDate__c",
      type: "date",
      sortable: false,
      typeAttributes: {
        month: "2-digit",
        day: "2-digit",
        year: "numeric"
      }
    },
    {
      label: "Subscription End Date",
      fieldName: "SBQQ__SubscriptionEndDate__c",
      type: "date",
      sortable: false,
      typeAttributes: {
        month: "2-digit",
        day: "2-digit",
        year: "numeric"
      }
    },
    {
      label: "Segment Label",
      fieldName: "SBQQ__SegmentLabel__c",
      type: "String",
      sortable: false
    },
    {
      label: "Annualized Amount",
      fieldName: "Annualized_Amount__c",
      type: "currency",
      sortable: false
    },
    {
      label: "End Date Within a Year?",
      fieldName: "End_Date_Within_a_Year__c",
      type: "boolean",
      sortable: false
    }
  ];

  error;
  subscriptionList;
  totalRecords;
  relatedListLableWithCount;

  connectedCallback() {
    getSubscriptions({
      contractId: this.recordId,
      filter: this.showInactiveSubscription
    })
      .then((result) => {
        this.subscriptionList = result;
        this.totalRecords = this.subscriptionList?.length ?? 0;
        this.relatedListLableWithCount =
          this.relatedListLable + " (" + this.totalRecords + ")";
      })
      .catch((error) => {
        this.error = error;
      });
  }
}
